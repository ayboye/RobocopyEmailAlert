XmlSendmail v1.4.1 (c) 2004-2008 by David Levinson
---------------------------------------------

About XmlSendmail
=================
XmlSendmail is a command-line utility for the intel (DOS/Windows) platform 
allows for the sending emails via an xml configuration file. This utility
was derived from a need for the ability to send emails from the 
command-line that was easy to install, supported authentication with an 
SMTP server, and allowed for the sendmail parameters to be specified via 
an xml configuration file. 

Their are several free sendmail products available, however, they either 
require the installation of perl, do not support SMTP servers that 
require authentication, or don't support xml based configuration.   

This command-line utility allows for discreet configuration files that 
can be passed into this utility to send an email.

The xml config file contains information about the smtp server, the sender, 
the recipient(s), and the message being sent. This config file is then 
passed to the sendmail utility at the command line.

example usage ...

C:\> sendmail message1.xml 

sendmail returns the following return codes.

0  =  success
-1 =  failure

Config file stucture
====================

NOTE: This structure IS case sensitive!!!

<Sendmail>
    <!-- hostname = name of the smpt server to use -->
    <!-- port = name of the smpt server port to use -->
    <!-- username = username if smtp server is authenticting -->
    <!-- password = password if smtp server is authenticting -->
    <Server host="www.myhost.com" port="25" username="" password=""/>   
    <Message>
        <!-- email = email of sender-->
        <!-- name = name of sender-->
        <Sender email="someone@myhost.com" name="someone"/>
        <!-- email = email of recipient-->
        <!-- name = name of recipient-->
    	<Recipient email="person@myhost.com" name="person"/>
        <!-- email = email of BCC recipient-->
        <!-- name = name of BCC recipient-->
        <BCCRecipient email="person@myhost.com"/>
        <!--  subject of email -->
      	<Subject>Test Subject</Subject>
        <!--  filename (optional) = name of file to use for body contents -->
        <!--  contentType (optional) = content-type for the message body. defaults to text/plain -->
      	<Body filename="test.txt" contentType="text/html; charset=US-ASCII"><![CDATA[This is a sample message body]]></Body>
    </Message>    
    <!-- filename = filename of attachment -->
    <!-- title = title of attachment -->
    <Attachment filename="test1.txt" title="test document1"/>
    <Attachment filename="test2.txt" title="test document2"/>
</Sendmail>
 

SAMPES
======

<Sendmail>
    <Server host="www.myhost.com" port="25" username="" password=""/>   
    <Message>
    	<Sender email="someone@myhost.com" name="someone"/>
    	<Recipient email="person@myhost.com" name="person"/>
        <BCCRecipient email="person2@myhost.com" name="person"/>
        <!-- using external body content -->
      	<Body filename="test.txt"/>
    </Message>    
    <Attachment filename="test1.txt" title="test document1"/>
</Sendmail>

<Sendmail>
    <Server host="www.myhost.com" port="25" username="" password=""/>   
    <Message>
    	<Sender email="someone@myhost.com" name="someone"/>
    	<Recipient email="person@myhost.com" name="person"/>
        <!-- using internal body content -->
      	<Body><![CDATA[This is a sample message body]]></Body>
    </Message>    
    <Attachment filename="test1.txt" title="test document1"/>
</Sendmail>
